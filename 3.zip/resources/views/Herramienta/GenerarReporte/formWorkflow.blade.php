<div class="row">
    <div class="panel panel-info">
        <div class="panel-body">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="checkbox">
                    <input type="checkbox" name="workterminados">
                    <label for="workterminados">Incluir Forkflows Terminados</label>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="checkbox">
                    <input type="checkbox" name="workproceso">
                    <label for="workproceso">Incluir Forkflows en Proceso</label>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="checkbox">
                    <input type="checkbox" name="users">
                    <label for="users">Incluir Usuarios por Workflow</label>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="checkbox">
                    <input type="checkbox" name="docs">
                    <label for="docs">Incluir Documentos por Workflow</label>
                </div>
            </div>
        </div>

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            </div>
            <div class="form-group">
                <button class="btn btn-warning" type="submit" >Generar</button>
            </div>
        </div>
    </div>
</div>
